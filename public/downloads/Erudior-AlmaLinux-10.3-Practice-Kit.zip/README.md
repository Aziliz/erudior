# AlmaLinux 10.3 practice lab for RHCSA and RHCE in Ansible

Use one official installer for both courses. The smaller **Erudior-setup.iso** in this kit is a second, read-only disc with the guest configuration scripts. The host launcher attaches both discs. Keep the four scripts and the setup disc together with **lab.py** after extracting the ZIP.

**Already using Erudior's graded RHCSA desktop exam?** Open the completed attempt, save its result, select **Reset exam disks**, then **Prepare machines** for a fresh attempt. Use **Begin** when ready for the timer. The desktop app supplies its own guest identities, exercises and isolated overlays. See “Graded desktop template” below for its one-time image setup. The host commands below manage the separate manual practice pair.

## 1. Get and verify the installation DVD

[Download AlmaLinux 10.3 x86_64 DVD ISO](https://repo.almalinux.org/almalinux/10.3/isos/x86_64/AlmaLinux-10.3-x86_64-dvd.iso) · [Signed checksums](https://repo.almalinux.org/almalinux/10.3/isos/x86_64/CHECKSUM) · [Release notes and signing fingerprint](https://wiki.almalinux.org/release-notes/10.3) · [AlmaLinux signing key](https://repo.almalinux.org/almalinux/RPM-GPG-KEY-AlmaLinux-10)

Use the full DVD for the standard x86_64 architecture. It carries BaseOS and AppStream for the offline installation and package labs. Its exact size is **10,824,908,800 bytes**. The SHA-256 digest is **f74ae9c4a8e7e3e70147534856ea276f71649d16c70b7d3ec80d0905a7b93982**. The host launcher checks both before creating any lab disks.

The kit also includes the upstream signed CHECKSUM and public key. To inspect them with GnuPG from the kit directory on Linux:

```bash
keyring=$(mktemp -d)
gpg --homedir "$keyring" --show-keys --with-fingerprint RPM-GPG-KEY-AlmaLinux-10
gpg --homedir "$keyring" --dearmor --output "$keyring/alma.gpg" RPM-GPG-KEY-AlmaLinux-10
gpg --homedir "$keyring" --no-default-keyring --keyring "$keyring/alma.gpg" --verify CHECKSUM
sha256sum ~/Downloads/AlmaLinux-10.3-x86_64-dvd.iso
```

Match the full primary fingerprint **EE6D B7B9 8F5B F5ED D9DA 0DE5 DEE5 C11C C2A1 E572** against the release notes. Look for a good signature, then match the computed digest to the exact DVD filename in CHECKSUM. If the distribution moves the point release to its archive, use an official AlmaLinux mirror with that same filename and digest.

## 2. Create the two manual guests

Use a Linux desktop host with Python 3.9+, QEMU system x86 with a graphical display, and qemu-img. On Fedora install `sudo dnf install python3 qemu-system-x86 qemu-img qemu-ui-gtk`. On Debian install `sudo apt install python3 qemu-system-x86 qemu-system-gui qemu-utils`. Windows users can run the Linux launcher inside a graphical WSL 2 distro with WSLg. Store its VM disks on the distro's Linux filesystem. On macOS the Erudior graded desktop route uses Lima. For this manual launcher use a graphical Linux VM with sufficient resources. KVM acceleration is used on eligible x86_64 hosts with accessible /dev/kvm. Software emulation uses QEMU's max CPU. Allow at least 8 GiB for the pair plus memory for the host and enough disk for the DVD, both installed systems, and a standalone copy at each saved baseline.

| Setting | Server | Client |
| --- | --- | --- |
| Virtual CPU and memory | 2 vCPUs, 4 GiB | 2 vCPUs, 4 GiB |
| Install destination | 30 GiB system disk | 30 GiB system disk |
| Practice storage after installation | Two blank 2 GiB disks | Two blank 2 GiB disks |
| Private host address | 192.168.77.10/24 | 192.168.77.20/24 |
| RHCE role | Managed node | Ansible control node |
| Virtual network | Private link plus a separate NAT uplink | Same private link, independent NAT uplink |

The private link uses a loopback socket on host port 25763 for RHCSA or 25764 for RHCE. Guest traffic stays off the physical LAN. Port 25763/25764 must be free on the host. Use the local guest consoles. The launcher creates its disks inside **~/Erudior-Practice/rhcsa** or **~/Erudior-Practice/rhce**. Use one track at a time if memory is limited. Keep each track directory at its original path because qcow2 overlays reference absolute baseline paths.

From the extracted kit directory on the host, substitute **rhce** for **rhcsa** throughout if building the automation pair.

```bash
python3 lab.py init rhcsa ~/Downloads/AlmaLinux-10.3-x86_64-dvd.iso
python3 lab.py install rhcsa server
```

In the installer choose **Minimal Install**, automatic partitioning of the single 30 GiB disk, a local user **learner**, a password you choose, and **administrator** membership. Complete installation and reboot from the system disk. Leave the server VM running for the client’s private-network connection. If you closed it, run `python3 lab.py start rhcsa server` first.

```bash
python3 lab.py install rhcsa client
```

Make the same installation choices on the client. After both installations, power off both from their consoles with `sudo systemctl poweroff`. Run `python3 lab.py start rhcsa` on the host. This normal boot attaches both storage-practice disks to each machine and starts the server before the client. Only the system disk was present during installation.

## 3. Configure and check the guests

At each guest console, as learner, mount the supplied setup disc. The installer DVD stays attached for packages. The setup script selects the private NIC by the MAC assigned by the launcher.

```bash
sudo mkdir -p /mnt/erudior-tools
sudo mount -o ro /dev/disk/by-label/ERUDIORLAB /mnt/erudior-tools
```

| Where to run it | RHCSA | RHCE |
| --- | --- | --- |
| Server console | `sudo bash /mnt/erudior-tools/prepare-guest.sh rhcsa server` | `sudo bash /mnt/erudior-tools/prepare-guest.sh rhce server` |
| Client console | `sudo bash /mnt/erudior-tools/prepare-guest.sh rhcsa client` | `sudo bash /mnt/erudior-tools/prepare-guest.sh rhce client` |

For offline RHCE web-package labs, set the playbook repository base URL to `file:///mnt/erudior-dvd/{{ item }}/` on the managed server. Keep the exercise’s repository IDs, signing key, GPG checks and explicit repository selection. The installed DVD supplies both the catalogs and signed RPMs.

Both profiles enable SSH, the firewall and chrony, use AlmaLinux's trusted key for RPM packages, and require enforcing SELinux. The course DVD repositories are disabled by default and explicitly selected for setup. On later offline package exercises use `sudo dnf --disablerepo='*' --enablerepo='erudior-dvd-*' list --available`. The guest mounts the attached installer DVD on demand after reboot.

**RHCSA.** The server supplies a read-only NFS marker restricted to the client and an initially stopped, disabled maintenance unit. The client has an empty repository catalog for the repository exercise. The practice disks, learner account tasks, automount configuration, storage layouts and service-repair work are left for the learner. After both machines are configured run `sudo bash /mnt/erudior-tools/check-guest.sh rhcsa server` on the server and `sudo bash /mnt/erudior-tools/check-guest.sh rhcsa client` on the client. The client check mounts and reads the actual NFS export, then unmounts it.

**RHCE.** From the server console display the fingerprint with `sudo ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub`. As **learner on the client**, run `bash /mnt/erudior-tools/pair-control.sh`, compare the fingerprint when prompted, and enter the credentials you chose. The helper creates or reuses the dedicated learner key, verifies the remote hostname, runs an Ansible ping and requests sudo to confirm UID 0. It ends the temporary SSH agent. Run `sudo bash /mnt/erudior-tools/check-guest.sh rhce server` and `sudo bash /mnt/erudior-tools/check-guest.sh rhce client` on the corresponding guests.

For the Navigator and editor practicals, keep NAT online during one-time preparation. As **learner on the RHCE client**, run `bash /mnt/erudior-tools/stage-rhce-tools.sh`. This stages the course’s pinned Navigator version, rootless Podman execution image and development image, then executes Ansible in the locally stored runtime. Open the course’s VS Code Dev Containers workspace once while online to stage the editor components and establish the workspace mounts. Use the course's **Identify the Ansible runtime** and **Author and run an inspection play in VS Code** lessons to verify the actual editor and playbook workflow. Retain the previous unit's inputs when capturing a later practical's baseline. Red Hat uses RHEL 10 for EX200 and Red Hat Ansible Automation Platform for EX294. These are Erudior practice profiles.

## 4. Capture once and reset for each attempt

Reboot once and confirm the expected private addresses, SELinux state and peer access. Remount the setup disc to run the checks again if needed. Save your baseline **after preparation and before solving the test**. At each guest console use `sudo systemctl poweroff`. On the **host**, run the command for your track:

```bash
python3 lab.py capture rhcsa
# For the separately prepared automation pair:
python3 lab.py capture rhce
```

For your **next fresh attempt** use one host command:

```bash
python3 lab.py reset rhcsa --start --offline
# Or:
python3 lab.py reset rhce --start --offline
```

Reset gracefully powers off any running guests on that track, switches all six disks to fresh overlays of the saved baseline as one operation, and optionally starts the pair. `--offline` restricts the new guests' NAT uplinks and keeps their private connection. Omit it for lessons that need external downloads. Without `--start`, the reset pair stays off. Changes since capture are discarded, including guest-local Git commits and assessment evidence. Save work you want to keep outside the VMs first. After a cold boot, reload any passphrase-protected key into your terminal’s SSH agent. The key and its trust records on disk return with the baseline.

A **named baseline** is useful when a practical starts partway through the course. For the RHCE web promotion, first complete the blue deployment, run the blue endpoint checker, and shut down both guests. Then use:

```bash
python3 lab.py capture rhce --baseline web-blue
python3 lab.py reset rhce --baseline web-blue --start --offline
python3 lab.py status rhce
```

Reusing an existing capture name is refused. Resetting one track leaves the other track and all saved baselines alone. If a broken guest cannot handle ACPI shutdown, `python3 lab.py reset rhce --force-off --start --offline` requests an immediate power-off of that track’s disposable VMs before restoring them. Use the correct track and baseline name. The launcher refuses a reset when no such baseline exists. A preparation failure leaves the current disk set selected. Close any external program that has opened a practice disk before retrying.

## Graded desktop template

Use the combined RHCSA course's **First-time setup** for its Linux provider (Linux directly, WSL 2 or Lima). The desktop runner expects a standalone BIOS-bootable qcow2 with NoCloud support and a serial console. Obtain the standard [AlmaLinux 10.3 x86_64 Generic Cloud image and checksums](https://repo.almalinux.org/almalinux/10.3/cloud/x86_64/images/), work on a separate copy and attach the verified installer DVD and the supplied setup disc. In that temporary guest mount ERUDIORLAB as above and run `sudo bash /mnt/erudior-tools/prepare-guest.sh desktop-template`. This installs the engine prerequisites and enables the ttyS0 serial login. The runner configures each attempt's user, addresses, private link and task fixtures.

Check NoCloud support, enforcing SELinux, and serial login. Remove provisioning-only credentials from the template copy, run `sudo cloud-init clean --logs --machine-id` and power it off. Flatten the powered-off image with `qemu-img convert -O qcow2 SOURCE.qcow2 almalinux-10-rhcsa.qcow2` to a new destination. `qemu-img info --backing-chain almalinux-10-rhcsa.qcow2` should show one standalone disk. Install it inside the provider's **~/.local/share/erudior-vm-labs/images/** directory, or its configured XDG data directory. Keep any older base image while attempts still refer to it. Follow the combined course's image profile and use its normal **Prepare machines / Begin / Save exam result / Reset exam disks** controls. A manual lab reset has no access to desktop exam records.

[Red Hat EX200 objectives](https://www.redhat.com/en/services/training/ex200-red-hat-certified-system-administrator-rhcsa-exam) · [Red Hat EX294 objectives](https://www.redhat.com/en/services/training/ex294-red-hat-certified-engineer-rhce-exam-red-hat-enterprise-linux)
