#!/usr/bin/env bash
# Run as learner on the RHCE client, with the server online. Interactive by design.
set -euo pipefail
[[ $(id -un) == learner && $(hostname -s) == client ]] || { echo 'Use learner on the client console.' >&2; exit 1; }
key=$HOME/.ssh/erudior_rhce
install -d -m 0700 "$HOME/.ssh"
if [[ ! -f $key ]]; then ssh-keygen -t ed25519 -f "$key"; fi
if [[ ! -f $key.pub ]]; then ssh-keygen -y -f "$key" > "$key.pub"; fi
echo 'Compare the first SSH fingerprint with sudo ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub at the server console.'
ssh-copy-id -o HostKeyAlgorithms=ssh-ed25519 -i "$key.pub" learner@192.168.77.10
ssh -o StrictHostKeyChecking=yes -o IdentitiesOnly=yes -i "$key" learner@192.168.77.10 'test "$(hostname -s)" = server && python3 --version'
eval "$(ssh-agent -s)" >/dev/null
trap 'ssh-agent -k >/dev/null' EXIT
ssh-add "$key"
ANSIBLE_HOST_KEY_CHECKING=True ansible all -i '192.168.77.10,' -u learner --private-key "$key" -m ansible.builtin.ping
ANSIBLE_HOST_KEY_CHECKING=True ansible all -i '192.168.77.10,' -u learner --private-key "$key" -b -K -m ansible.builtin.command -a 'id -u'
echo 'Expect pong and UID 0. The temporary agent exits when setup finishes.'
