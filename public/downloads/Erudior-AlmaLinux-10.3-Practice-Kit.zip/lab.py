#!/usr/bin/env python3
"""Manage the two Erudior manual practice guests on a Linux QEMU host."""
import argparse
import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time
import uuid

DVD_SHA = "f74ae9c4a8e7e3e70147534856ea276f71649d16c70b7d3ec80d0905a7b93982"
DVD_SIZE = 10824908800
ROLES = ("server", "client")
DISKS = {f"{role}-{kind}.qcow2": size for role in ROLES
         for kind, size in (("system", "30G"), ("practice1", "2G"), ("practice2", "2G"))}
BASE_DIR = Path.home() / "Erudior-Practice"

def image(*args, capture=False):
    return subprocess.run(["qemu-img", *map(str, args)], check=True,
                          stdout=subprocess.PIPE if capture else None, text=True)

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def syncdir(path):
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def commit(root, state):
    temp = root / ".state.next"
    with temp.open("w") as f:
        json.dump(state, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, root / "state.json")
    syncdir(root)

def new_set(root, tag):
    path = root / (tag + "-" + uuid.uuid4().hex)
    path.mkdir(mode=0o700)
    return path

def cleanup_known(path):
    if {p.name for p in path.iterdir()} <= DISKS.keys():
        for p in path.iterdir():
            p.unlink()
        path.rmdir()

def guard_dir(root, name, tag):
    if not isinstance(name, str) or len(name) != len(tag) + 33 or not name.startswith(tag+"-"):
        raise ValueError("Invalid disk set name in lab state")
    uuid.UUID(hex=name[len(tag)+1:])
    path = root / name
    if path.is_symlink() or not path.is_dir():
        raise ValueError("Disk set is missing or is a symlink")
    return path

def runtime(root):
    p = Path(tempfile.gettempdir()) / ("erudior-qmp-" + str(os.getuid()))
    p.mkdir(mode=0o700, exist_ok=True)
    if p.is_symlink() or p.stat().st_uid != os.getuid() or p.stat().st_mode & 0o077:
        raise ValueError("QMP directory must be private and owned by the current user")
    return p / hashlib.sha256(str(root).encode()).hexdigest()[:14]

def qpath(root, role):
    return str(runtime(root)) + "-" + role + ".sock"

def qmp(root, role, command):
    with socket.socket(socket.AF_UNIX) as sock:
        sock.settimeout(4)
        sock.connect(qpath(root, role))
        with sock.makefile("rwb") as stream:
            def receive():
                line = stream.readline()
                if not line:
                    raise EOFError("QEMU closed its control socket")
                return json.loads(line)
            if "QMP" not in receive():
                raise RuntimeError("Unexpected QEMU greeting")
            for operation in ("qmp_capabilities", command):
                stream.write((json.dumps({"execute": operation}) + "\n").encode())
                stream.flush()
                while True:
                    try:
                        reply = receive()
                    except EOFError:
                        if operation == "quit":
                            return {}
                        raise
                    if "error" in reply:
                        raise RuntimeError(str(reply["error"]))
                    if "return" in reply:
                        break
            return reply["return"]

def running(root, role):
    if not os.path.exists(qpath(root, role)):
        return False
    try:
        qmp(root, role, "query-status")
        return True
    except (FileNotFoundError, ConnectionRefusedError, ConnectionResetError, BrokenPipeError, EOFError):
        return False

def check_disks(path):
    for name in DISKS:
        disk = path / name
        if not disk.is_file() or disk.is_symlink():
            raise ValueError("Missing regular disk: " + str(disk))
        # Deliberately omit --force-share. An external writer must release the disk.
        info = json.loads(image("info", "--output=json", disk, capture=True).stdout)
        if info["format"] != "qcow2":
            raise ValueError("Expected qcow2: " + name)

def quiesce(root, active, shutdown, force_off=False):
    live = [role for role in ROLES if running(root, role)]
    if live and not shutdown:
        raise ValueError("Power off both guests before capturing the baseline")
    for role in live:
        try:
            qmp(root, role, "quit" if force_off else "system_powerdown")
        except (BrokenPipeError, ConnectionResetError):
            if not force_off:
                raise
    deadline = time.monotonic() + 120
    while any(running(root, role) for role in live):
        if time.monotonic() >= deadline:
            raise ValueError("Shutdown timed out. Shut down the listed practice VMs at their consoles and retry. The current disk set is intact.")
        time.sleep(1)
    check_disks(active)

def init(root, args):
    if (root / "state.json").exists():
        raise ValueError("This track already exists")
    iso = args.iso.expanduser().resolve(strict=True)
    if iso.stat().st_size != DVD_SIZE or digest(iso) != DVD_SHA:
        raise ValueError("The installer does not match the signed AlmaLinux 10.3 x86_64 DVD checksum")
    active = new_set(root, "work")
    try:
        for name, size in DISKS.items():
            image("create", "-q", "-f", "qcow2", active / name, size)
        commit(root, {"version": 1, "track": args.track, "iso": str(iso), "active": active.name, "bases": {}})
    except Exception:
        if not (root/"state.json").exists():
            cleanup_known(active)
        raise

def capture(root, state, active, label):
    if label in state["bases"]:
        raise ValueError("That baseline already exists. Choose another name to capture a different starting state.")
    quiesce(root, active, False)
    for role in ROLES:
        with tempfile.NamedTemporaryFile(dir=root) as sector:
            image("dd", "-f", "qcow2", "bs=512", "count=1", "if="+str(active/(role+"-system.qcow2")), "of="+sector.name)
            data = Path(sector.name).read_bytes()
            if len(data)!=512 or data[510:512]!=b"\x55\xaa" or not any(data[i] for i in (450,466,482,498)):
                raise ValueError("No installed partition table on the "+role+" system disk")
    base = new_set(root, "base")
    try:
        for name in DISKS:
            image("convert", "-f", "qcow2", "-O", "qcow2", active/name, base/name)
            image("check", "-q", "-f", "qcow2", base/name)
            (base/name).chmod(0o400)
        syncdir(base)
        commit(root, {**state, "bases": {**state["bases"], label: base.name}})
    except Exception:
        recorded = json.loads((root/"state.json").read_text())
        if recorded["bases"].get(label) != base.name:
            cleanup_known(base)
        raise
    print("Captured both guests and four practice disks. The baseline is read-only.")

def reset(root, state, active, label, force_off=False):
    if label not in state["bases"]:
        raise ValueError("Capture the configured pair before the first reset")
    base = guard_dir(root, state["bases"][label], "base")
    check_disks(base)
    quiesce(root, active, True, force_off)
    fresh = new_set(root, "work")
    try:
        for name in DISKS:
            image("create", "-q", "-f", "qcow2", "-F", "qcow2", "-b", base/name, fresh/name)
        check_disks(fresh)
        syncdir(fresh)
        commit(root, {**state,"active":fresh.name})
    except Exception:
        recorded = json.loads((root/"state.json").read_text())
        if recorded["active"] != fresh.name:
            cleanup_known(fresh)
        raise
    cleanup_known(active)
    print("Reset complete. Both system disks and all four practice disks now use the captured baseline.")
    return fresh

def launch(root, state, active, role, install=False, offline=False):
    if running(root, role):
        if install:
            raise ValueError(role+" is already running")
        return
    if install and state["bases"]:
        raise ValueError("Installer boot is disabled after baseline capture")
    iso = Path(state["iso"])
    seed = Path(__file__).resolve().with_name("Erudior-setup.iso")
    if not iso.is_file() or iso.stat().st_size != DVD_SIZE or not seed.is_file():
        raise ValueError("Keep the verified DVD at its registered path and the setup ISO beside lab.py")
    idx = ROLES.index(role)
    port = 25763 if state["track"]=="rhcsa" else 25764
    trackid = 50 if state["track"]=="rhcsa" else 51
    hw = os.uname().machine=="x86_64" and os.access("/dev/kvm",os.R_OK|os.W_OK)
    # QEMU keyval syntax escapes literal commas by doubling them.
    esc = lambda p: str(p).replace(",",",,")
    args = ["qemu-system-x86_64","-name","Erudior-"+state["track"]+"-"+role,"-machine","pc",
            "-accel","kvm" if hw else "tcg","-cpu","host" if hw else "max","-smp","2","-m","4096",
            "-boot","once=d,order=c" if install else "order=c","-daemonize",
            "-qmp","unix:"+esc(qpath(root,role))+",server=on,wait=off",
            "-netdev","user,id=nat"+(",restrict=on" if offline else ""),
            "-device",f"virtio-net-pci,netdev=nat,mac=52:54:00:{trackid}:01:{10+idx}",
            "-netdev",f"socket,id=lab,{'listen' if idx==0 else 'connect'}=127.0.0.1:{port}",
            "-device",f"virtio-net-pci,netdev=lab,mac=52:54:00:{trackid}:02:{10+idx}"]
    for kind in (("system",) if install else ("system","practice1","practice2")):
        args += ["-drive",f"if=virtio,format=qcow2,file={esc(active/(role+'-'+kind+'.qcow2'))}"]
    args += ["-drive",f"if=ide,index=2,media=cdrom,readonly=on,file={esc(iso)}",
             "-drive",f"if=ide,index=3,media=cdrom,readonly=on,file={esc(seed)}"]
    subprocess.run(args,check=True)
    print("Started "+role)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest="action",required=True)
    for op in ("init","install","start","status","capture","reset"):
        p=sub.add_parser(op)
        p.add_argument("track",choices=("rhcsa","rhce"))
        if op=="init":p.add_argument("iso",type=Path)
        if op=="install":p.add_argument("role",choices=ROLES)
        if op=="start":p.add_argument("role",nargs="?",choices=ROLES)
        if op in ("capture","reset"):p.add_argument("--baseline",default="exam",help="saved starting state (default: exam)")
        if op=="reset":p.add_argument("--force-off",action="store_true",help="power off these disposable practice guests immediately before reset")
        if op=="reset":p.add_argument("--start",action="store_true",help="boot both guests after reset")
        if op in ("start","reset"):p.add_argument("--offline",action="store_true",help="restrict NAT egress on each newly launched guest")
    args=parser.parse_args()
    if hasattr(args,"baseline") and not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,47}",args.baseline):
        parser.error("Use a short lowercase baseline name with letters, digits or hyphens.")
    os.umask(0o077)
    root=BASE_DIR/args.track
    if args.action=="init":
        root.mkdir(mode=0o700,parents=True,exist_ok=True)
    elif not (root/"state.json").is_file():
        raise ValueError("Initialize this track first")
    with (root/"lab.lock").open("a") as f:
        try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise ValueError("Another lab operation is running") from None
        if args.action=="init":
            init(root,args)
            return
        state=json.loads((root/"state.json").read_text())
        if state["version"]!=1 or state["track"]!=args.track:
            raise ValueError("Unexpected lab profile")
        active=guard_dir(root,state["active"],"work")
        if args.action=="status":
            print("Baselines:",", ".join(state["bases"]) or "none captured")
            for role in ROLES:print(role, "running" if running(root,role) else "off")
        elif args.action=="capture":capture(root,state,active,args.baseline)
        elif args.action=="install":
            if args.role=="client" and not running(root,"server"):
                raise ValueError("Leave the server running while installing the client for the private link")
            launch(root,state,active,args.role,install=True)
        else:
            if args.action=="reset":
                active=reset(root,state,active,args.baseline,args.force_off)
                if not args.start:return
            roles = (args.role,) if getattr(args,"role",None) else ROLES
            for role in roles:
                if role=="client" and not running(root,"server"):
                    raise ValueError("Start the server first for the private link")
                launch(root,state,active,role,offline=args.offline)

if __name__=="__main__":
    try:main()
    except (OSError,EOFError,KeyError,ValueError,RuntimeError,subprocess.SubprocessError) as e:
        sys.exit("Lab: "+str(e))
