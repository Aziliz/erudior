#!/usr/bin/env bash
# Run from the learner console inside a dedicated course VM.
set -euo pipefail
usage() { echo 'Usage: sudo bash prepare-guest.sh {rhcsa|rhce} {server|client}  OR  sudo bash prepare-guest.sh desktop-template' >&2; exit 2; }
[[ $EUID == 0 ]] || { echo 'Run with sudo inside the practice guest.' >&2; exit 2; }
source /etc/os-release
[[ $ID == almalinux && $VERSION_ID == 10.3 && $(uname -m) == x86_64 ]] || { echo 'Expected an AlmaLinux 10.3 x86_64 practice guest.' >&2; exit 1; }
track=${1:-}; role=${2:-}
if [[ $track == desktop-template && $# == 1 ]]; then
  role=template
elif [[ $# == 2 && ( $track == rhcsa || $track == rhce ) && ( $role == server || $role == client ) ]]; then
  mac_track=50
  [[ $track == rhce ]] && mac_track=51
  host_octet=10; mac_role=10
  if [[ $role == client ]]; then host_octet=20; mac_role=11; fi
  mac="52:54:00:$mac_track:02:$mac_role"
  dev=''
  for path in /sys/class/net/*; do
    if [[ $(cat "$path/address") == "$mac" ]]; then dev=${path##*/}; fi
  done
  [[ -n $dev ]] || { echo "Cannot identify the course private adapter ($mac). Check the track and role." >&2; exit 1; }
  id learner >/dev/null
  id -nG learner | tr ' ' '\n' | grep -Fx wheel >/dev/null || { echo 'Make learner an administrator in the installer.' >&2; exit 1; }
else usage; fi

# Install only from the attached release DVD, including dependencies.
install -d -m 0755 /mnt/erudior-dvd
if ! mountpoint -q /mnt/erudior-dvd; then mount -o ro /dev/disk/by-label/AlmaLinux-10-3-x86_64-dvd /mnt/erudior-dvd; fi
root=/mnt/erudior-dvd
for repo in BaseOS AppStream; do test -s "$root/$repo/repodata/repomd.xml"; done
dvd_device=$(findmnt -n -t iso9660 -o SOURCE --mountpoint "$root")
[[ $(blkid -s LABEL -o value "$dvd_device") == AlmaLinux-10-3-x86_64-dvd ]] || { echo 'Mount the verified AlmaLinux 10.3 x86_64 DVD at /mnt/erudior-dvd.' >&2; exit 1; }
key=/etc/pki/rpm-gpg/RPM-GPG-KEY-AlmaLinux-10
test -s "$key"
install -d /etc/yum.repos.d
repo_file=/etc/yum.repos.d/erudior-dvd.repo
if [[ -e $repo_file ]] && ! grep -qx '# Managed by Erudior practice setup' "$repo_file"; then echo "Existing non-course file: $repo_file" >&2; exit 1; fi
cat > "$repo_file" <<EOF
# Managed by Erudior practice setup
[erudior-dvd-baseos]
name=AlmaLinux 10.3 course DVD BaseOS
baseurl=file://$root/BaseOS
enabled=0
gpgcheck=1
gpgkey=file://$key
[erudior-dvd-appstream]
name=AlmaLinux 10.3 course DVD AppStream
baseurl=file://$root/AppStream
enabled=0
gpgcheck=1
gpgkey=file://$key
EOF
base=(python3 python3-dnf sudo coreutils util-linux NetworkManager openssh-server openssh-clients firewalld chrony selinux-policy-targeted policycoreutils-python-utils man-db man-pages vim-minimal tar)
if [[ $track == rhcsa || $role == template ]]; then
  base+=(autofs nfs-utils tuned lvm2 xfsprogs e2fsprogs dosfstools parted at cronie flatpak createrepo_c grubby bzip2 info httpd)
fi
if [[ $role == template ]]; then base+=(cloud-init); fi
if [[ $track == rhce && $role == client ]]; then base+=(ansible-core git-core podman python3-pip); fi
dnf -y --disablerepo='*' --enablerepo=erudior-dvd-baseos,erudior-dvd-appstream install "${base[@]}"
[[ $(getenforce) == Enforcing ]] || { echo 'Enable SELinux enforcing in this VM and reboot before capturing.' >&2; exit 1; }
if [[ $role == template ]]; then
  systemctl enable serial-getty@ttyS0.service
  grubby --update-kernel=ALL --args='console=tty0 console=ttyS0,115200n8'
  systemctl is-enabled cloud-init.target
  python3 -c 'import dnf'
  rm -f -- "$repo_file"
  echo 'Template packages ready. Complete the identity and cloud-init cleanup in README.md before shutdown.'
  exit
fi
# Keep the offline package source available across a reboot with the DVD attached.
if ! awk '$2 == "/mnt/erudior-dvd" {found=1} END {exit !found}' /etc/fstab; then
  printf 'LABEL=AlmaLinux-10-3-x86_64-dvd /mnt/erudior-dvd iso9660 ro,nofail,x-systemd.automount,x-systemd.device-timeout=5s 0 0\n' >> /etc/fstab
  systemctl daemon-reload
elif ! awk '$1=="LABEL=AlmaLinux-10-3-x86_64-dvd" && $2=="/mnt/erudior-dvd" {found=1} END {exit !found}' /etc/fstab; then
  echo 'Inspect the existing DVD mount in /etc/fstab before using this profile.' >&2; exit 1
fi
hostnamectl set-hostname "$role"
systemctl enable --now firewalld
zone=internal
if [[ $track == rhcsa ]]; then
  zone=rhcsa-lab
  if ! firewall-cmd --permanent --get-zones | tr ' ' '\n' | grep -Fx "$zone" >/dev/null; then
    firewall-cmd --permanent --new-zone="$zone"
    firewall-cmd --reload
  fi
fi
profile="lab-private"
if ! nmcli -g NAME connection show | grep -Fx "$profile" >/dev/null; then
  nmcli connection add type ethernet con-name "$profile" ifname "$dev"
fi
# Bind to hardware identity. Kernel interface names can change across installer and normal boots.
nmcli connection modify "$profile" connection.interface-name '' 802-3-ethernet.mac-address "$mac" \
  connection.autoconnect yes connection.autoconnect-priority 999 ipv4.method manual \
  ipv4.addresses "192.168.77.$host_octet/24" ipv4.gateway '' ipv4.never-default yes ipv4.dns '' \
  ipv6.method disabled connection.zone "$zone"
nmcli connection up "$profile"
systemctl enable --now sshd firewalld chronyd
firewall-cmd --permanent --zone="$zone" --add-service=ssh
firewall-cmd --zone="$zone" --add-service=ssh
if [[ $track == rhcsa && $role == server ]]; then
  install -d -m 0755 /srv/projects
  printf 'Erudior practice share\n' > /srv/projects/erudior-lab.txt
  chmod 0644 /srv/projects/erudior-lab.txt
  install -d /etc/exports.d
  printf '/srv/projects 192.168.77.20(ro,sync,root_squash)\n' > /etc/exports.d/shift.exports
  restorecon -RF /srv/projects
  systemctl enable --now nfs-server
  exportfs -ra
  firewall-cmd --zone="$zone" --add-service=nfs
  firewall-cmd --permanent --zone="$zone" --add-service=nfs
  cat > /etc/systemd/system/erudior-maint.service <<'UNIT'
[Unit]
Description=Branch maintenance startup marker
[Service]
Type=oneshot
ExecStart=/usr/bin/touch /run/erudior-maint.ready
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl disable --now erudior-maint.service
elif [[ $track == rhcsa && $role == client ]]; then
  install -d /srv/erudior-repo
  test -s /srv/erudior-repo/repodata/repomd.xml || createrepo_c /srv/erudior-repo
fi
ip -br -4 address show "$dev"
printf 'Configured %s for %s. Run the readiness checks before capturing a baseline.\n' "$role" "$track"
