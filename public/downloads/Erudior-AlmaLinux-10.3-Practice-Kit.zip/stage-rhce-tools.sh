#!/usr/bin/env bash
# One-time ONLINE preloading for EX294 practice after the two guests work.
set -euo pipefail
[[ $(id -un) == learner && $(hostname -s) == client ]] || { echo 'Run as learner on the RHCE client.' >&2; exit 1; }
[[ $(podman info --format '{{.Host.Security.Rootless}}') == true ]]
nav="$HOME/.venvs/rhce-nav"
python3 -m venv "$nav"
"$nav/bin/python" -m pip install 'ansible-navigator==26.11.0'
ee=ghcr.io/ansible-community/community-ee-minimal:2.21.6-1
dev=ghcr.io/ansible/community-ansible-dev-tools@sha256:e416af142ddf3af7f88bca5867077a5cf87e09c551e62ef1d651658a2ae9f952
podman pull "$ee"
podman pull "$dev"
podman tag "$dev" localhost/erudior/rhce-dev:unit2
work=$(mktemp -d); trap 'rm -rf -- "$work"' EXIT
cd "$work"
cat > ansible-navigator.yml <<EOF
---
ansible-navigator:
  mode: stdout
  execution-environment:
    enabled: true
    container-engine: podman
    image: $ee
    pull:
      policy: never
  playbook-artifact:
    enable: false
EOF
"$nav/bin/ansible-navigator" --version
"$nav/bin/ansible-navigator" exec -- ansible --version
podman image inspect --format '{{.Digest}}' "$ee"
echo 'Navigator ran the local execution environment. Open the course editor workbench once online before an offline editor exercise.'
