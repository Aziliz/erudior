#!/usr/bin/env bash
# Run inside a freshly prepared manual guest. Exit nonzero at the first failure.
set -euo pipefail
track=${1:-}; role=${2:-}
fail() { echo "FAIL $*" >&2; exit 1; }
trap 'echo "Readiness check stopped at line $LINENO" >&2' ERR
[[ $EUID == 0 ]] || fail 'use sudo'
[[ $track == rhcsa || $track == rhce ]] || fail 'specify rhcsa or rhce'
[[ $role == server || $role == client ]] || fail 'specify server or client'
source /etc/os-release
[[ $ID == almalinux && $VERSION_ID == 10.3 && $(uname -m) == x86_64 ]] || fail 'release'
[[ $(hostname -s) == "$role" && $(getenforce) == Enforcing ]] || fail 'hostname or SELinux'
id -nG learner | tr ' ' '\n' | grep -Fx wheel >/dev/null
rpm -q openssh-server firewalld chrony python3 >/dev/null
for svc in sshd firewalld chronyd; do
  systemctl is-enabled --quiet "$svc"
  systemctl is-active --quiet "$svc"
done
address=192.168.77.10; peer=192.168.77.20
if [[ $role == client ]]; then address=192.168.77.20; peer=192.168.77.10; fi
nm-online -q -t 45 || fail 'NetworkManager has not finished connecting'
dev=$(nmcli -g GENERAL.DEVICES connection show lab-private)
[[ -n $dev && $dev != -- ]] || fail 'lab-private is inactive; inspect nmcli device status and the private adapter MAC' 
ip -o -4 addr show dev "$dev" | grep -F " $address/24 " >/dev/null
ip -4 route get "$peer" | grep -F "dev $dev " >/dev/null
ping -c 1 -W 3 "$peer" >/dev/null || fail 'private peer; boot and configure both guests before running this check'
for disk in vdb vdc; do
  [[ -b /dev/$disk ]] || fail "missing /dev/$disk"
  [[ $(lsblk -dnbo SIZE "/dev/$disk") == 2147483648 ]] || fail "$disk capacity"
done
if [[ $track == rhcsa ]]; then
  rpm -q autofs nfs-utils tuned flatpak lvm2 >/dev/null
  if [[ $role == server ]]; then
    exportfs -v | grep -F '/srv/projects' >/dev/null
    test -s /srv/projects/erudior-lab.txt
    [[ $(systemctl is-enabled erudior-maint.service || :) == disabled ]] || fail 'maintenance unit should start disabled'
    [[ $(systemctl is-active erudior-maint.service || :) == inactive ]] || fail 'maintenance unit should start stopped'
  else
    test -s /srv/erudior-repo/repodata/repomd.xml
    # Use a temporary read-only mount to verify the actual export and leave autofs for the learner.
    tmp=$(mktemp -d)
    trap 'if mountpoint -q "$tmp"; then umount "$tmp"; fi; rmdir "$tmp"' EXIT
    mount -t nfs -o ro,vers=4,retry=0 192.168.77.10:/srv/projects "$tmp"
    test -s "$tmp/erudior-lab.txt"
  fi
elif [[ $role == client ]]; then
  rpm -q ansible-core git-core podman >/dev/null
  ansible-playbook --version | head -n 1
fi
printf 'PASS %s %s AlmaLinux %s, peer %s\n' "$track" "$role" "$VERSION_ID" "$peer"
